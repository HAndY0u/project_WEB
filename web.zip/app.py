from flask import Flask, render_template, json, request

app = Flask(__name__)


@app.route('/')
def main():
    return render_template('index.html')


@app.route('/Kazan')
def Kazan():
    return render_template('Kazan.html')


@app.route('/SPB')
def SPB():
    return render_template('SPB.html')


@app.route('/Moscow')
def Moscow():
    return render_template('Moscow.html')


if __name__ == "__main__":
    app.run()
